"""Place des caméras sur une vraie carte (ex. Ouagadougou) à partir de coordonnées GPS.

1. Exporter une image de carte sur https://www.openstreetmap.org (Exporter, zone manuelle, noter nord / ouest / est / sud).
2. Lancer le serveur (les caméras à placer doivent exister, voir « Gestion des caméras »), puis :

    .\\venv\\Scripts\\python.exe tools\\city_map.py carte.png
    .\\venv\\Scripts\\python.exe tools\\city_map.py capture.png --pixels      (capture Google Maps d'Ouagadougou 1546 x 865 px)
    .\\venv\\Scripts\\python.exe tools\\city_map.py carte.png --bbox -1.56,12.33,-1.47,12.40 --cameras entre,salle,couloir,rue

--bbox = ouest,sud,est,nord (degrés) de l'image exportée. L'image doit être en projection Web Mercator (cas des exports OpenStreetMap).
Les emplacements des caméras sont INDICATIFS : les ajuster ensuite en les déplaçant dans la page Carte.
Fond de carte : © les contributeurs d'OpenStreetMap (ODbL), à mentionner dans le pitch.
"""
import argparse
import json
import math
import struct
import sys
import urllib.error
import urllib.request
import uuid

DEFAULT_BBOX = (-1.56, 12.33, -1.47, 12.40)
# (libellé, lieu, latitude, longitude, direction en degrés, 0 = haut) : repères approximatifs d'Ouagadougou
SPOTS = [
    ("Place de la Nation", "Centre-ville", 12.3714, -1.5197, 90),
    ("Marché Rood Woko", "Grand marché", 12.3655, -1.5253, 0),
    ("Aéroport", "Aéroport international", 12.3532, -1.5124, 270),
    ("Université Joseph Ki-Zerbo", "Campus", 12.3810, -1.4990, 180),
]
# Variante « capture d'écran » (--pixels) : positions repérées à la main sur la capture Google Maps d'Ouagadougou de 1546 x 865 px.
# (libellé, lieu, x en px, y en px, direction)
PIXEL_REF = (1546, 865)
PIXEL_SPOTS = [
    ("Centre-ville", "Cœur de ville", 845, 505, 90),
    ("Université Joseph Ki-Zerbo", "Campus", 1000, 395, 180),
    ("Stade du 4 Août", "Stade", 459, 473, 90),
    ("Aéroport Thomas Sankara", "Aéroport international", 921, 636, 0),
]
FOV, RANGE = 90.0, 0.05      # ouverture en degrés ; portée en fraction de la largeur de l'image


def _merc_y(lat: float) -> float:
    return math.log(math.tan(math.pi / 4 + math.radians(lat) / 2))


def to_xy(lat: float, lon: float, bbox) -> tuple:
    """Position relative (0-1) dans une image Web Mercator couvrant bbox = (ouest, sud, est, nord)."""
    west, south, east, north = bbox
    x = (lon - west) / (east - west)
    y = (_merc_y(north) - _merc_y(lat)) / (_merc_y(north) - _merc_y(south))
    return x, y


def _request(method: str, url: str, body=None, headers=None):
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else None)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")
    except urllib.error.URLError as exc:
        raise SystemExit(f"Serveur injoignable ({exc.reason}). Lancer d'abord l'application.")


def _multipart(fields: dict, filename: str, data: bytes) -> tuple:
    boundary = uuid.uuid4().hex
    parts = []
    for k, v in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\n'
                  'Content-Type: application/octet-stream\r\n\r\n').encode() + data + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("image", help="image de la carte (PNG ou JPEG)")
    ap.add_argument("--bbox", default=",".join(map(str, DEFAULT_BBOX)), help="ouest,sud,est,nord de l'image")
    ap.add_argument("--cameras", default="entre,salle,couloir,rue", help="identifiants des caméras à placer, dans l'ordre des repères")
    ap.add_argument("--pixels", action="store_true", help="placer les caméras selon les positions repérées sur la capture Google Maps (sans GPS)")
    ap.add_argument("--name", default="Ouagadougou")
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    args = ap.parse_args()
    try:
        bbox = tuple(float(v) for v in args.bbox.split(","))
        assert len(bbox) == 4 and bbox[0] < bbox[2] and bbox[1] < bbox[3]
    except (ValueError, AssertionError):
        raise SystemExit("--bbox attendu : ouest,sud,est,nord (ouest < est, sud < nord).")
    ids = [c.strip() for c in args.cameras.split(",") if c.strip()]
    data = open(args.image, "rb").read()
    body, ctype = _multipart({"name": args.name, "level": "0"}, args.image.replace("\\", "/").rsplit("/", 1)[-1], data)
    status, floor = _request("POST", args.url + "/api/floors", body, {"Content-Type": ctype})
    if status != 201 and status != 200:
        raise SystemExit(f"Import refusé ({status}) : {floor}")
    placed = 0
    spots = ([(lb, li, px / PIXEL_REF[0], py / PIXEL_REF[1], h) for lb, li, px, py, h in PIXEL_SPOTS] if args.pixels
             else [(lb, li) + to_xy(lat, lon, bbox) + (h,) for lb, li, lat, lon, h in SPOTS])
    for cid, (label, lieu, x, y, head) in zip(ids, spots):
        if not (0 <= x <= 1 and 0 <= y <= 1):
            print(f"  ignorée : {label} est hors de l'image")
            continue
        payload = {"floor_id": floor["id"], "x": round(x, 4), "y": round(y, 4), "heading": head, "fov": FOV,
                   "view_range": RANGE, "label": label, "location": lieu}
        st, res = _request("PUT", f"{args.url}/api/admin/cameras/{cid}", json.dumps(payload).encode(),
                           {"Content-Type": "application/json"})
        print(f"  {'OK ' if st == 200 else 'ERR'} {cid} -> {label} ({x:.3f}, {y:.3f})" + ("" if st == 200 else f" : {res}"))
        placed += st == 200
    print(f"Carte « {args.name} » importée, {placed} caméra(s) placée(s). Ouvrir {args.url}/map")
    return 0 if placed else 1


if __name__ == "__main__":
    sys.exit(main())
