# NiifYéén

**Plateforme web de supervision vidéo multi-caméras** : détection de personnes, suivi d'une cible d'une caméra à l'autre, comptage et zones, alertes, enregistrement d'incidents, statistiques et rapports PDF. Le tout dans une interface en français, sans dépendance cloud.

Projet réalisé en Python (FastAPI) lors d'un hackathon, puis structuré en 14 modules. Les captures ci-dessous ont été prises avec des **caméras simulées** (silhouettes sans visage, personnes fictives) : le bandeau « démonstration » visible dessus vient d'une version précédente du projet, où ce mode existait.

![Centre de supervision](docs/screenshots/supervision.png)

## Ce que fait le projet

| Domaine | Fonctions |
| --- | --- |
| **Supervision** | Mosaïque de 1 à 16 caméras, état en ligne / hors ligne, flux d'événements en direct, mode moniteur plein écran, caméras réparties sur plusieurs ordinateurs |
| **Détection et suivi** | Détection de personnes (YOLOv8) et suivi local (ByteTrack), ré-identification entre caméras |
| **Cibles** | Désigner une personne comme cible, la suivre sur plusieurs caméras, afficher son trajet sur le plan et le rejouer |
| **Lignes et zones** | Lignes de comptage (entrées / sorties), zones avec capacité, zones interdites (intrusion), présence prolongée |
| **Alertes** | Règles par type d'événement, priorités, regroupement des doublons, prise en charge par l'opérateur, notifications externes optionnelles |
| **Carte** | Plans par étage, caméras placées avec direction et champ de vision, analyse de couverture et d'angles morts |
| **Enregistrement** | Clips vidéo déclenchés par les événements (avec pré-enregistrement), lecteur, export |
| **Analyse** | Statistiques anonymes (fréquentation, cartes de chaleur, comparaison de périodes, transitions entre caméras), investigation d'une personne ou d'une cible, rapports PDF paramétrables |

<table>
<tr>
<td><img src="docs/screenshots/carte.png" alt="Carte et couverture des caméras"></td>
<td><img src="docs/screenshots/alertes.png" alt="Centre d'alertes"></td>
</tr>
<tr>
<td><img src="docs/screenshots/statistiques.png" alt="Statistiques"></td>
<td><img src="docs/screenshots/rapports.png" alt="Rapports PDF"></td>
</tr>
</table>

## Pile technique

- **Backend** : Python 3.10+, FastAPI, Uvicorn (HTTP et WebSocket), SQLAlchemy 2 avec SQLite
- **Vision** : OpenCV, YOLOv8 et ByteTrack (Ultralytics), InsightFace (reconnaissance faciale, optionnelle)
- **Frontend** : HTML, CSS et JavaScript sans framework ni étape de build, avec thème clair / sombre et interface adaptée au mobile
- **Rapports** : ReportLab (PDF)
- **Tests** : `unittest`, plus des tests de la logique JavaScript exécutés avec Node.js

## Architecture

```
Caméras (webcam, RTSP, flux d'un autre PC)
        │
   Capture + détection + suivi (un fil par caméra)
        │
   ┌────┴────────────────────────────┐
   │ Cibles · Analyse (lignes/zones) │──► Fil d'événements ──► Alertes · Enregistrement · WebSocket
   └────┬────────────────────────────┘                              │
        │                                                           ▼
   SQLite (détections, zones, alertes, plans…)             Interface web (FastAPI + pages statiques)
```

Chaque module reste indépendant du navigateur : le suivi des cibles, les comptages et les alertes tournent côté serveur, que la page soit ouverte ou non. Le code est dans `backend/app/` (un fichier par domaine : `analytics.py`, `alerts.py`, `recordings.py`, `stats.py`, `reports.py`, `floors.py`…), les pages dans `backend/app/static/`.

## Lancer avec de vraies caméras

```powershell
Copy-Item cameras.example.json cameras.json     # facultatif : import initial des caméras
.\venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
```

Les caméras se gèrent ensuite depuis la page « Gestion des caméras ». Le serveur écoute uniquement sur `127.0.0.1`. Le guide complet (configuration, variables d'environnement, caméras distantes, dépannage) est dans [docs/DOCUMENTATION.md](docs/DOCUMENTATION.md).

## Tests

```powershell
.\venv\Scripts\python.exe -B -m unittest discover -s tests -t . -v
```

734 tests, sans caméra ni modèle : logique de comptage, alertes, migrations de base de données, API, validation des entrées, génération de rapports. Un test vérifie aussi qu'aucune page n'utilise `innerHTML`.

## Choix de conception

- **Vie privée par défaut** : les statistiques, rapports et notifications externes sont anonymes ; les identités n'apparaissent que dans les écrans nominatifs (investigation, fiche de la cible). Les secrets passent uniquement par des variables d'environnement.
- **Sécurité** : serveur local, plans importés assainis (SVG sans script), aucun `innerHTML`, validation stricte des entrées, adresses de flux jamais renvoyées en clair par l'API.
- **Migrations sans perte** : une ancienne base SQLite est mise à niveau au démarrage.

## Limites connues

- Prototype : la détection, le suivi et la reconnaissance n'ont **pas été évalués sur de vraies caméras** et les seuils ne sont pas calibrés.
- La couverture sur plan est géométrique : elle ignore murs et obstacles, c'est donc un maximum.
- Les zones se tracent sur l'image de chaque caméra, pas directement sur le plan. Le multi-sites n'est pas implémenté.
- Les notifications e-mail et Telegram ne sont testées qu'avec des simulations.
- Testé sous Windows avec Chromium ; Firefox et Safari ne sont pas vérifiés.
- Les enregistrements vidéo peuvent contenir des visages : ils relèvent des règles de protection des données applicables à l'usage.

## Données personnelles et usage responsable

Le projet contient des fonctions de reconnaissance faciale. Il ne doit être utilisé qu'avec le **consentement des personnes enrôlées** et dans le respect de la réglementation locale sur la vidéosurveillance et les données biométriques. Aucune base, photo ni empreinte n'est fournie avec le code (voir `.gitignore`).

## Pour aller plus loin

[Documentation technique complète](docs/DOCUMENTATION.md) · [Plan de développement en 14 modules](docs/NIIFYEEN_2_0_PLAN.md)
